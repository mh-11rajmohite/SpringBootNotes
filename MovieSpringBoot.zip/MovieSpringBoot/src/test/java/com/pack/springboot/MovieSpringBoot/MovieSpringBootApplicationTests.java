/*
 * package com.pack.springboot.MovieSpringBoot;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class MovieSpringBootApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */